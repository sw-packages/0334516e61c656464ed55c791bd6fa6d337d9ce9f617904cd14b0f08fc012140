#ifndef TOML11_FORMAT_HPP
#define TOML11_FORMAT_HPP

#include "fwd/format_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/format_impl.hpp" // IWYU pragma: export
#endif

#endif// TOML11_FORMAT_HPP
