#ifndef TOML11_COLOR_HPP
#define TOML11_COLOR_HPP

#include "fwd/color_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/color_impl.hpp" // IWYU pragma: export
#endif

#endif // TOML11_COLOR_HPP
